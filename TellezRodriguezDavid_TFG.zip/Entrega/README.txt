TFG David T�llez Rodr�guez: Generador de niveles para videojuegos del g�nero plataforma - Computaci�n evolutiva y Super Mario Bros

1. El c�digo adjunto en la carpeta "Codigo" puede lanzarse ejecutando la clase ch.idsia.scenarios.Play.

2. Para ejecutar una soluci�n u otra, comentar/descomentar las l�neas pertinentes en ch.idsia.mario.engine.LevelScene.java:621-628.

3. Al compilar de nuevo el proyecto se puede obtener un error que consiste en que Java el archivo "tiles.dat". Para solucionarlo,
copiar src/ch/idsia/mario/engine/resources/tiles.dat a classes/ch/idsia/mario/engine. Este es un error conocido de la plataforma y dado lo intrincado
de su programaci�n, se ha optado por esta soluci�n frente a intentar un cambio en el c�digo.