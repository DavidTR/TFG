__author__="Sergey Karakovskiy, sergey at idsia fullstop ch"
__date__ ="$May 13, 2009 12:17:14 AM$"

from marioenvironment import MarioEnvironment

